import 'package:flutter/material.dart';

void main() {
    runApp(MyApp1());
}

class MyApp1 extends StatelessWidget {
    @override
    Widget build(BuildContext context){
        return MaterialApp(
            home:MyApp()
        );


    }
}



class MyApp extends StatefulWidget {
    @override
    _MyApp createState() => _MyApp();
}

class _MyApp extends State<MyApp> {

    @override
    Widget build(BuildContext context){

        return MaterialApp(
            title:'Typhoid',
            home:Scaffold(
                appBar:AppBar(title:Text("Typhoid")),
                body:Center(
                    child:Column(
                        mainAxisAlignment:MainAxisAlignment.center,
                        children:<Widget>[
                            Container(
                                margin: const EdgeInsets.all(10.0),
                                color: Colors.amber[600],
                                width: 200.0,
                                height: 200.0,
                                child:Column(
                                children:<Widget>[
                                   Text("The Work ig Goin on thsi side")
                                ],
                                )
                            ),
                        ],
                    )
                ),

            ),
        );

    }

    Future  _showMyDialog(BuildContext context){
        return showDialog(
            context: context,
            builder: (BuildContext context) {
                return AlertDialog(
                    title: Text('Not in stock'),
                    content: const Text('This item is no longer available'),
                    actions: [
                        FlatButton(
                            child: Text('Ok'),
                            onPressed: () {
                                Navigator.of(context).pop();
                            },
                        ),
                    ],
                );
            },
        );
    }


}
